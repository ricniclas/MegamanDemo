Game: Mega Man X
Developer: Capcom
Platoform: MS-DOS
Year: 1995-96

Ripped by Nero1024, credit not required!
--------
Included here are all of the samples used in the MS-DOS version of Mega Man X.
The samples were all .RAW audio files located in the RAW folder of the game. The sample data were ripped with the RAW audio import feature of Audacity.

The files are unnamed and some may not be pitched correctly but they're all there.
--------